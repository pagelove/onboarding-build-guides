# Collected Light — Invitation / dark

Source: pagelove/design-system @ f41f4476b636c3b353f024c2cb9a1e2067b7de6b. Use the complete selected design. Use blue-black backgrounds, warm off-white text, dusty lavender accents, literary serif headings and generous spacing. Keep the interface calm and avoid bright neon treatments. Use the bundled local fonts and product compositions. Separate page, panel and inset surfaces; keep metadata quiet but readable. Use the exported page/panel/row spacing and title scale consistently, with 44px action targets and brief 160ms interaction feedback. See docs/polish.md for the complete product contract.

Read site/assets/pagelove-design/DESIGN.md (mode-specific), polish.md and identity-and-sharing.md. Use canonical type/spacing/shape roles and local WOFF2 fonts. Neutral borders, no colored card rails or decorative northeast arrows. App-specific layout is site/styles.css; it must not mix another palette into the selected design.

Identity authority: branding/site.json and branding/mark.svg. Update the public URL for a new deployment, then run npm install and npm run branding. The source-pinned renderer lives in scripts/identity-kit; branding/renderer-input.json is derived upstream configuration, not app-domain data. Never edit generated identity/social exports directly.

HTML source records, aggregate boundaries, save/recovery and accepted limits remain in docs/architecture.md and DOCUMENT-FIRST-REVIEW.md. This refresh preserves all records and domain formats. Browser and metadata verification pending for this revision.

## Album-first composition

Current entry uses library.css over the same canonical Invitation/dark tokens and local fonts. Album covers lead, with a compact three-column photo grid (two columns on narrow screens), calm neutral borders, meaningful cover imagery and clear edit/save states. Buttons retain brand foreground/background roles. The full-size viewer uses contained images and keyboard/pointer navigation; no decorative NE arrows or colored card rails are introduced.
